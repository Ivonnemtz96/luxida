<?php
$title = 'Servicios';
require_once('include/head.php');
require_once('include/header.php');
require_once('modules/servicios/renta.php');
require_once('include/footer.php');
?>