<?php
$title = 'Contacto';
require_once('include/head.php');
require_once('include/header.php');
require_once('modules/contacto.php');
require_once('include/footer.php');
?>