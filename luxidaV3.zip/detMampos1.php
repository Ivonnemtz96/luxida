<?php
$title = 'Productos';
require_once('include/head.php');
require_once('include/header.php');
require_once('modules/detailsProduct/prodMampos.php');
require_once('include/footer.php');
?>