 <!--== Start Page Title Area ==-->
 <section class="page-title-area bg-img" data-bg-img="/assets/img/photos/servicios.jpg">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-lg-12 m-auto">
                 <div class="page-title-content text-center">
                     <h2 class="title">Productos</h2>
                     <div class="bread-crumbs"><a href="/">Inicio</a>
                         <span class="breadcrumb-sep"> // </span>
                         <span>Productos</span>
                         <span class="breadcrumb-sep"> // </span>
                         <span class="active">Block</span>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="bg-overlay3"></div>
 </section>
 <!--== End Page Title Area ==-->
 <div class="row align-items-center">
     <div class="col-lg-7 m-auto text-center" style="padding-top: 5rem;">
         <h1>Block</h1>
         <p>
             Tenemos alianzas comerciales con los principales productores de Concretos y Block de la zona para su distribución, nuestro personal está altamente capacitado para poder brindar la mejor atención y asesoría a nuestros clientes, garantizando la calidad de los productos y manejando precios competitivos en el mercado actual.
            </p>
     </div>
 </div>