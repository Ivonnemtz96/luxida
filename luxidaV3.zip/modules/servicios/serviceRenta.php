  <!--== Start Service Area Wrapper ==-->
  <section class="service-area service-grid-area">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-10">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-4">
                          <img src="/assets/img/service/maquinaria/856h.jpg" alt="">
                      </div>
                      <div class="col-8">
                        <h2>Retroexcavadora con o sin martillo</h2>
                          <p>
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi debitis hic, minus illum totam inventore voluptatibus? Aut error nesciunt numquam quidem pariatur aspernatur voluptatum eos voluptate assumenda, maiores optio sequi rerum deserunt nostrum quo illo delectus nemo, vitae distinctio harum iure! Fugiat, quos ducimus accusantium explicabo natus ullam quasi omnis.
                          </p>
                      </div>
                  </div>
              </div>

              <div class="col-10">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-8">
                          <h2>Cargador Frontal</h2>
                          <p>
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi debitis hic, minus illum totam inventore voluptatibus? Aut error nesciunt numquam quidem pariatur aspernatur voluptatum eos voluptate assumenda, maiores optio sequi rerum deserunt nostrum quo illo delectus nemo, vitae distinctio harum iure! Fugiat, quos ducimus accusantium explicabo natus ullam quasi omnis.
                          </p>
                      </div>
                      <div class="col-4">
                          <img src="/assets/img/service/maquinaria/excavadora.jpg" alt="">
                      </div>
                  </div>
              </div>

              <div class="col-10">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-4">
                          <img src="/assets/img/service/maquinaria/maquinaria.jpg" alt="">
                      </div>
                      <div class="col-8">
                          <h2>Excavadora cono sin martillo</h2>
                          <p>
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi debitis hic, minus illum totam inventore voluptatibus? Aut error nesciunt numquam quidem pariatur aspernatur voluptatum eos voluptate assumenda, maiores optio sequi rerum deserunt nostrum quo illo delectus nemo, vitae distinctio harum iure! Fugiat, quos ducimus accusantium explicabo natus ullam quasi omnis.
                          </p>
                      </div>
                  </div>
              </div>

              <div class="col-10">
                  <div class="row justify-content-center align-items-center">
                      <div class="col-8">
                          <h2>Moffet</h2>
                          <p>
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi debitis hic, minus illum totam inventore voluptatibus? Aut error nesciunt numquam quidem pariatur aspernatur voluptatum eos voluptate assumenda, maiores optio sequi rerum deserunt nostrum quo illo delectus nemo, vitae distinctio harum iure! Fugiat, quos ducimus accusantium explicabo natus ullam quasi omnis.
                          </p>
                      </div>
                      <div class="col-4">
                          <img src="/assets/img/service/2.webp.jpeg" alt="">
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <!--== End Service Area Wrapper ==-->