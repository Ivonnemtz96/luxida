<section class="laja" data-bg-img="/assets/img/photos/lajas.jpg">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-12 m-auto">
                <div class="page-title-content text-center">
                    <h2 class="detail">Productos</h2>
                    <div class="bread-crumbs"><a href="/">Inicio</a>
                         <span class="breadcrumb-sep"> // </span>
                         <span>Productos</span>
                         <span class="breadcrumb-sep"> // </span>
                         <span class="active">Piedra laja</span>
                     </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-overlay3"></div>
</section>