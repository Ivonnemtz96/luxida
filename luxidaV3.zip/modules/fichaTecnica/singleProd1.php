<?php
include("bann1.php");
?>

<div class="row align-items-center">
    <div class="col-6 text-center" style="padding-top: 5rem; margin-bottom: 5rem">
        <img src="/assets/img/productos/laja1.jpg" alt="">
    </div>

    <div class="col-6 text-start">
        <h4>Especificaciones técnicas</h4>
        <p>
            <ul>
                <li> 54 kg./m2 peso aproximado.</li>
                <li> Largo: 20 a 56 cm.</li>
                <li> Ancho: 15 a 38 cm.</li>
                <li> Grosor: 4 cm.</li>

            </ul>
            Es una roca plana, lisa y poco gruesa, cuyos colores van desde el ocre hasta el marrón, y se separa en tablas fácilmente, debido a la estratificación en los yacimientos.
        </p>
    </div>

    <section class="laja" data-bg-img="/assets/img/photos/trabajo1.jpg">
    </section>
</div>