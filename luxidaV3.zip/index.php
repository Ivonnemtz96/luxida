<?php
$title = 'Inicio';
require_once('include/head.php');
require_once('include/header.php');
require_once('modules/index.php');
require_once('include/footer.php');
?>